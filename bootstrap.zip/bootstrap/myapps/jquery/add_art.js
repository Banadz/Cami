$(document).ready(function(){
    // adding article
    var addArt = $('.addArt');
    $(addArt).on('click',function(){
        $('#AdditionModal').modal('show');
        
        $tr = $(this).closest('tr');
        var info =  $tr.children("td").map(function(){
            return $(this).text();
        }).get();

        var id = info[0];

        $('#xunitaire').hide();
        $('#xmonta').hide();
        $('#type_prix').on('blur', function(){
            var choice =  $('#type_prix option:selected').val();
            if (choice === 'yes'){
                $('#xunitaire').fadeIn(500);
            }else{
                $('#xmonta').fadeIn();
            }
        });
        $('#type_prix').on('focus', function(){
            $('#xunitaire').hide();
            $('#xmonta').hide();
            $('#prix_uni').attr('value','');
            $('#id_montant').attr('value','');
        });
        $('#prix_uni').on('blur', function(){
            $('#xmonta').fadeIn(1000);
            var number1 = $("#id_effectif").val();
            var number2 = $('#prix_uni').val();
            var qte = parseInt(number1);
            var uni = parseInt(number2);
            var mon = (qte * uni);
            mon = parseInt(mon);
            $('#id_montant').value = mon;
            $('#id_montant').attr('value', mon);
        });

        $('#fournisform').on('submit', function(def){
            def.preventDefault();
            var garbage = $(this).serialize();
            url = $(this).attr('action');
            var id = info[0];
            var qte = $("#id_effectif").val();
            swal({
                title: "Valider l'ajout",
                text: 'Voullez-vous ajouter '+qte+' sur article n° '+id+' !',
                icon: 'warning',
                buttons:{
                    confirm: {
                        text : 'Oui',
                        className : 'btn btn-success'
                    },
                    cancel: {
                        visible: true,
                        text:'Annuler',
                        className: 'btn btn-danger'
                    }
                }
            }).then((Delete) => {
                if (Delete) {
                    $.ajax({
                        url: url,
                        type:'GET',
                        data: 'id='+id+'&&'+garbage,
                        dataType:'json',
                        success:function(reponse,status){
                            console.log(reponse);
                            if(reponse.error){
                                swal("Echéc", reponse.error, {
                                    icon : "error",
                                    buttons: {        			
                                        confirm: {
                                            className : 'btn btn-danger'
                                        }
                                    },
                                });
                                console.log(reponse.error);
                            }
                            if(reponse.success){
                                swal("Succés", reponse.success, {
                                    icon : "success",
                                    buttons: {        			
                                        confirm: {
                                            className : 'btn btn-success',
                                            
                                        }
                                    },
                                }).then((Delete) => {
                                    if (Delete) {     
                                        window.location.reload();
                                    }

                                });

                            }
                        }
                    })
                } else {
                    swal.close();
                }
            });
        });
        
    });
});